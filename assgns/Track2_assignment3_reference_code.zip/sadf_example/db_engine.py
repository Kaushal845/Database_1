"""
Unified Database Engine for the Self-Adaptive Database Framework (SADF).

Operates on two SQLite files:
  • sql.db   – normalised relational tables (users, sensors, readings)
  • mongo.db – document store simulation (JSON blobs keyed by collection + record_id)

Every public method consults the MetadataManager to decide which backend(s) to touch.
"""

import sqlite3
import json
import uuid
import os
from datetime import datetime
from metadata_manager import MetadataManager

BASE_DIR = os.path.dirname(__file__)
SQL_DB   = os.path.join(BASE_DIR, "sql.db")
MONGO_DB = os.path.join(BASE_DIR, "mongo.db")


class DBEngine:
    """Metadata-driven CRUD engine across two SQLite backends."""

    def __init__(self):
        self.meta = MetadataManager()
        self._init_mongo_db()

    # ── helpers ──────────────────────────────────────────────────

    def _sql_conn(self):
        conn = sqlite3.connect(SQL_DB)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _mongo_conn(self):
        conn = sqlite3.connect(MONGO_DB)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_mongo_db(self):
        """Ensure the documents table exists in mongo.db."""
        conn = self._mongo_conn()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                collection  TEXT    NOT NULL,
                record_id   TEXT    NOT NULL,
                document    TEXT    NOT NULL,
                created_at  TEXT    NOT NULL,
                UNIQUE(collection, record_id)
            )
        """)
        conn.commit()
        conn.close()

    # ── Condition helpers ────────────────────────────────────────

    # Supported operators for conditional queries
    OPERATORS = {
        "eq": "=", "ne": "!=", "gt": ">", "gte": ">=",
        "lt": "<", "lte": "<=", "like": "LIKE", "in": "IN"
    }

    def _parse_conditions(self, conditions, allowed_fields=None):
        """
        Parse a conditions list into (sql_clauses, params) for SQL WHERE.
        Each condition: {"field": "...", "op": "eq|ne|gt|gte|lt|lte|like|in", "value": ...}
        Top-level list is AND by default; wrap in {"or": [...]} for OR.
        
        Returns (clause_str, param_list) or (None, []) if no SQL-applicable conditions.
        """
        if not conditions:
            return None, []
        return self._parse_condition_group(conditions, "and", allowed_fields)

    def _parse_condition_group(self, conditions, logic, allowed_fields):
        """Recursively parse condition groups with AND/OR logic."""
        clauses = []
        params  = []

        items = conditions if isinstance(conditions, list) else [conditions]
        for cond in items:
            # Nested OR group: {"or": [...]}
            if "or" in cond and isinstance(cond["or"], list):
                sub_clause, sub_params = self._parse_condition_group(cond["or"], "or", allowed_fields)
                if sub_clause:
                    clauses.append(f"({sub_clause})")
                    params.extend(sub_params)
                continue
            # Nested AND group: {"and": [...]}
            if "and" in cond and isinstance(cond["and"], list):
                sub_clause, sub_params = self._parse_condition_group(cond["and"], "and", allowed_fields)
                if sub_clause:
                    clauses.append(f"({sub_clause})")
                    params.extend(sub_params)
                continue

            field = cond.get("field")
            op    = cond.get("op", "eq")
            value = cond.get("value")
            if not field:
                continue
            if allowed_fields and field not in allowed_fields:
                continue
            sql_op = self.OPERATORS.get(op)
            if not sql_op:
                continue

            if op == "in":
                if not isinstance(value, list):
                    value = [value]
                placeholders = ", ".join(["?"] * len(value))
                clauses.append(f"{field} IN ({placeholders})")
                params.extend(value)
            else:
                clauses.append(f"{field} {sql_op} ?")
                params.append(value)

        joiner = " OR " if logic == "or" else " AND "
        return joiner.join(clauses) if clauses else None, params

    def _match_condition_in_memory(self, row, conditions):
        """
        Evaluate conditions against an in-memory row dict (for Mongo-side post-filtering).
        Returns True if the row matches all conditions.
        """
        if not conditions:
            return True
        return self._eval_group(row, conditions, "and")

    def _eval_group(self, row, conditions, logic):
        items = conditions if isinstance(conditions, list) else [conditions]
        results = []
        for cond in items:
            if "or" in cond and isinstance(cond["or"], list):
                results.append(self._eval_group(row, cond["or"], "or"))
                continue
            if "and" in cond and isinstance(cond["and"], list):
                results.append(self._eval_group(row, cond["and"], "and"))
                continue

            field = cond.get("field")
            op    = cond.get("op", "eq")
            value = cond.get("value")
            if not field:
                continue
            actual = row.get(field)
            results.append(self._compare(actual, op, value))

        if logic == "or":
            return any(results) if results else True
        return all(results) if results else True

    @staticmethod
    def _compare(actual, op, expected):
        """Compare a single value against expected using the given operator."""
        if actual is None:
            return False
        try:
            if op == "eq":  return actual == expected
            if op == "ne":  return actual != expected
            if op == "gt":  return float(actual) >  float(expected)
            if op == "gte": return float(actual) >= float(expected)
            if op == "lt":  return float(actual) <  float(expected)
            if op == "lte": return float(actual) <= float(expected)
            if op == "like":
                # SQL LIKE pattern → Python: % = .*, _ = .
                import re
                pattern = "^" + str(expected).replace("%", ".*").replace("_", ".") + "$"
                return bool(re.match(pattern, str(actual), re.IGNORECASE))
            if op == "in":
                vals = expected if isinstance(expected, list) else [expected]
                return actual in vals
        except (ValueError, TypeError):
            return False
        return False

    # ── READ ─────────────────────────────────────────────────────

    def read(self, entity, filters=None, conditions=None):
        """
        Read records for a logical entity.
        - filters: simple {field: value} equality (backward compatible)
        - conditions: rich list of {field, op, value} with AND/OR nesting
        Merges data from sql.db and mongo.db using record_id when needed.
        Returns a list of dicts.
        """
        routing = self.meta.get_routing(entity)
        sql_fields   = routing["sql_fields"]
        mongo_fields = routing["mongo_fields"]
        table        = routing["table"]
        collection   = routing["collection"]

        sql_rows  = []
        mongo_rows = []

        # ---------- SQL side ----------
        if sql_fields and table:
            conn = self._sql_conn()
            query = f"SELECT * FROM {table}"
            params = []
            where_parts = []

            # Simple equality filters
            if filters:
                for k, v in filters.items():
                    if k in sql_fields:
                        where_parts.append(f"{k} = ?")
                        params.append(v)

            # Rich conditions
            if conditions:
                cond_clause, cond_params = self._parse_conditions(conditions, sql_fields)
                if cond_clause:
                    where_parts.append(cond_clause)
                    params.extend(cond_params)

            if where_parts:
                query += " WHERE " + " AND ".join(where_parts)

            rows = conn.execute(query, params).fetchall()
            sql_rows = [dict(r) for r in rows]
            conn.close()

        # ---------- Mongo side ----------
        if mongo_fields and collection:
            conn = self._mongo_conn()
            query = "SELECT record_id, document FROM documents WHERE collection = ?"
            params = [collection]
            if filters and "record_id" in filters:
                query += " AND record_id = ?"
                params.append(filters["record_id"])
            rows = conn.execute(query, params).fetchall()
            for r in rows:
                doc = json.loads(r["document"])
                doc["record_id"] = r["record_id"]
                # Apply conditions as post-filter for Mongo-side fields
                if conditions:
                    mongo_conditions = [c for c in conditions
                                        if isinstance(c, dict) and c.get("field") in mongo_fields]
                    if mongo_conditions and not self._match_condition_in_memory(doc, mongo_conditions):
                        continue
                mongo_rows.append(doc)
            conn.close()

        # ---------- merge ----------
        result = []
        if sql_rows and mongo_rows:
            mongo_index = {r["record_id"]: r for r in mongo_rows}
            for sr in sql_rows:
                rid = sr.get("record_id")
                if rid and rid in mongo_index:
                    result.append({**sr, **mongo_index[rid]})
                else:
                    result.append(sr)
        else:
            result = sql_rows or mongo_rows

        # Final post-filter: ensure ALL conditions are met on merged rows
        if conditions and result:
            result = [r for r in result if self._match_condition_in_memory(r, conditions)]

        return result

    # ── CREATE ───────────────────────────────────────────────────

    def create(self, entity, data):
        """
        Insert a new record.  Splits data across backends based on metadata.
        Returns the generated record_id.
        """
        routing = self.meta.get_routing(entity)
        record_id = data.get("record_id", str(uuid.uuid4())[:12])
        data["record_id"] = record_id

        sql_data   = {k: v for k, v in data.items() if k in routing["sql_fields"]}
        mongo_data = {k: v for k, v in data.items() if k in routing["mongo_fields"] and k != "record_id"}

        # ---------- SQL insert ----------
        if sql_data and routing["table"]:
            conn = self._sql_conn()
            cols = ", ".join(sql_data.keys())
            placeholders = ", ".join(["?"] * len(sql_data))
            conn.execute(
                f"INSERT INTO {routing['table']} ({cols}) VALUES ({placeholders})",
                list(sql_data.values())
            )
            conn.commit()
            conn.close()

        # ---------- Mongo insert ----------
        if mongo_data and routing["collection"]:
            conn = self._mongo_conn()
            conn.execute(
                "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
                [routing["collection"], record_id, json.dumps(mongo_data), datetime.now().isoformat()]
            )
            conn.commit()
            conn.close()

        return record_id

    # ── UPDATE ───────────────────────────────────────────────────

    def update(self, entity, record_id, patch):
        """Update fields for a record, routing each field to its correct backend."""
        routing = self.meta.get_routing(entity)
        sql_patch   = {k: v for k, v in patch.items() if k in routing["sql_fields"] and k != "record_id"}
        mongo_patch = {k: v for k, v in patch.items() if k in routing["mongo_fields"] and k != "record_id"}

        if sql_patch and routing["table"]:
            conn = self._sql_conn()
            sets = ", ".join([f"{k} = ?" for k in sql_patch])
            conn.execute(
                f"UPDATE {routing['table']} SET {sets} WHERE record_id = ?",
                list(sql_patch.values()) + [record_id]
            )
            conn.commit()
            conn.close()

        if mongo_patch and routing["collection"]:
            conn = self._mongo_conn()
            row = conn.execute(
                "SELECT document FROM documents WHERE collection = ? AND record_id = ?",
                [routing["collection"], record_id]
            ).fetchone()
            if row:
                doc = json.loads(row["document"])
                doc.update(mongo_patch)
                conn.execute(
                    "UPDATE documents SET document = ? WHERE collection = ? AND record_id = ?",
                    [json.dumps(doc), routing["collection"], record_id]
                )
            conn.commit()
            conn.close()

    # ── DELETE ───────────────────────────────────────────────────

    def delete(self, entity, record_id):
        """Delete a record from all backends that hold it."""
        routing = self.meta.get_routing(entity)

        if routing["table"]:
            conn = self._sql_conn()
            conn.execute(f"DELETE FROM {routing['table']} WHERE record_id = ?", [record_id])
            conn.commit()
            conn.close()

        if routing["collection"]:
            conn = self._mongo_conn()
            conn.execute(
                "DELETE FROM documents WHERE collection = ? AND record_id = ?",
                [routing["collection"], record_id]
            )
            conn.commit()
            conn.close()

    # ── LOGICAL JSON QUERY ───────────────────────────────────────

    def execute_query(self, query_json):
        """
        Execute a logical query in JSON format.

        Supported format:
        {
            "operation": "read" | "create" | "update" | "delete",
            "entity":    "entity_name",
            "fields":    ["field1", "field2"],       // select specific fields (read)
            "filters":   {"field": "value"},          // simple equality (backward compat)
            "conditions": [                           // rich conditional filters (read)
                {"field": "temperature", "op": "gt", "value": 25},
                {"field": "role", "op": "in", "value": ["admin", "staff"]},
                {"or": [
                    {"field": "status", "op": "eq", "value": "active"},
                    {"field": "status", "op": "eq", "value": "maintenance"}
                ]}
            ],
            "data":      {...},                       // for create / update
            "order_by":  "field_name",                // sort (read)
            "order":     "asc" | "desc",              // sort direction
            "limit":     10                           // limit results (read)
        }

        Supported operators:
            eq  (=)   ne (!=)   gt (>)   gte (>=)
            lt  (<)   lte (<=)  like     in
        Logical groups: {"or": [...]}, {"and": [...]}
        """
        op     = query_json.get("operation", "read")
        entity = query_json.get("entity")
        if not entity:
            return {"error": "Missing 'entity' field"}

        if op == "read":
            conditions = query_json.get("conditions")
            rows = self.read(entity, query_json.get("filters"), conditions)

            # Field selection
            req_fields = query_json.get("fields")
            if req_fields:
                rows = [{k: r.get(k) for k in req_fields} for r in rows]

            # Sorting
            order_by = query_json.get("order_by")
            if order_by:
                desc = query_json.get("order", "asc").lower() == "desc"
                rows.sort(key=lambda r: (r.get(order_by) is None, r.get(order_by)), reverse=desc)

            # Limit
            limit = query_json.get("limit")
            if limit and isinstance(limit, int):
                rows = rows[:limit]

            return {"status": "ok", "count": len(rows), "data": rows}

        elif op == "create":
            rid = self.create(entity, query_json.get("data", {}))
            return {"status": "ok", "record_id": rid}

        elif op == "update":
            filters = query_json.get("filters", {})
            rid = filters.get("record_id")
            if not rid:
                return {"error": "Update requires filters.record_id"}
            self.update(entity, rid, query_json.get("data", {}))
            return {"status": "ok", "record_id": rid}

        elif op == "delete":
            filters = query_json.get("filters", {})
            rid = filters.get("record_id")
            if not rid:
                return {"error": "Delete requires filters.record_id"}
            self.delete(entity, rid)
            return {"status": "ok", "record_id": rid}

        return {"error": f"Unknown operation: {op}"}
    def search_all(self, query):
        """
        Search across all logical entities for a matching keyword.
        This provides a 'natural' search experience over the entire framework.
        """
        if not query:
            return []
            
        search_query = str(query).lower()
        results = []
        entities = self.meta.get_entities().keys()
        
        for entity in entities:
            # Fetch all records for each entity (optimised with a simple filter if possible, 
            # but for a self-adaptive framework, searching everything is safer).
            records = self.read(entity)
            for r in records:
                # Search all string values in the record
                match = False
                for v in r.values():
                    if search_query in str(v).lower():
                        match = True
                        break
                if match:
                    # Enrich record with entity type for frontend display
                    r["__entity"] = entity
                    results.append(r)
        
        return results
