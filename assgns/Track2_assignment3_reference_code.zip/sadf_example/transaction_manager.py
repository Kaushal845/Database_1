"""
Transaction Manager for the Self-Adaptive Database Framework (SADF).

Provides a coordination layer that ensures ACID properties across
the two SQLite backends (sql.db and mongo.db).
"""

import sqlite3
import json
import os
import uuid
import threading
import time
from datetime import datetime

BASE_DIR = os.path.dirname(__file__)
SQL_DB   = os.path.join(BASE_DIR, "sql.db")
MONGO_DB = os.path.join(BASE_DIR, "mongo.db")


class TransactionManager:
    """Cross-database transaction coordination with ACID validation."""

    def __init__(self):
        self._lock = threading.Lock()

    # ── low-level helpers ────────────────────────────────────────

    def _sql_conn(self):
        conn = sqlite3.connect(SQL_DB)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _mongo_conn(self):
        conn = sqlite3.connect(MONGO_DB)
        conn.row_factory = sqlite3.Row
        return conn

    # ── coordinated transaction ──────────────────────────────────

    def execute_transaction(self, sql_ops, mongo_ops):
        """
        Execute a list of (query, params) tuples on each backend atomically.
        If either side fails, both roll back.
        Returns {"status": "committed"} or {"status": "rolled_back", "error": ...}.
        """
        sql_conn = self._sql_conn()
        mongo_conn = self._mongo_conn()
        try:
            for query, params in sql_ops:
                sql_conn.execute(query, params)
            for query, params in mongo_ops:
                mongo_conn.execute(query, params)
            # Both succeeded → commit
            sql_conn.commit()
            mongo_conn.commit()
            return {"status": "committed"}
        except Exception as e:
            sql_conn.rollback()
            mongo_conn.rollback()
            return {"status": "rolled_back", "error": str(e)}
        finally:
            sql_conn.close()
            mongo_conn.close()

    # ── ACID validation tests ────────────────────────────────────

    def test_atomicity(self):
        """
        Atomicity: insert a reading into sql.db AND an event into mongo.db.
        Then simulate failure by attempting a duplicate insert (unique constraint).
        Verify that neither insert persists on failure.
        """
        record_id = f"atom-test-{uuid.uuid4().hex[:6]}"
        ts = datetime.now().isoformat()

        # Phase 1: successful cross-DB insert
        result = self.execute_transaction(
            sql_ops=[
                (
                    "INSERT INTO readings (record_id, sensor_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
                    [record_id, 1, ts, 25.5, 60.0]
                )
            ],
            mongo_ops=[
                (
                    "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
                    ["sensor_events", record_id, json.dumps({"event_type": "atomicity_test", "payload": {"test": True}}), ts]
                )
            ]
        )
        if result["status"] != "committed":
            return {"test": "atomicity", "passed": False, "reason": f"Phase 1 failed: {result.get('error')}"}

        # Phase 2: attempt duplicate → should fail and roll back both
        record_id_2 = f"atom-fail-{uuid.uuid4().hex[:6]}"
        result2 = self.execute_transaction(
            sql_ops=[
                (
                    "INSERT INTO readings (record_id, sensor_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
                    [record_id_2, 1, ts, 30.0, 55.0]
                )
            ],
            mongo_ops=[
                # Duplicate record_id → UNIQUE constraint violation
                (
                    "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
                    ["sensor_events", record_id, json.dumps({"event_type": "duplicate"}), ts]
                )
            ]
        )

        # Verify SQL record_id_2 was rolled back
        conn = self._sql_conn()
        row = conn.execute("SELECT * FROM readings WHERE record_id = ?", [record_id_2]).fetchone()
        conn.close()
        sql_rolled_back = row is None

        # Clean up phase 1 data
        self._cleanup_test_data(record_id)

        if result2["status"] == "rolled_back" and sql_rolled_back:
            return {"test": "atomicity", "passed": True, "reason": "Duplicate insert correctly rolled back both backends."}
        return {"test": "atomicity", "passed": False, "reason": "Rollback did not propagate correctly."}

    def test_consistency(self):
        """
        Consistency: attempt to insert a reading referencing a non-existent sensor_id.
        FK constraint should prevent it.
        """
        record_id = f"cons-test-{uuid.uuid4().hex[:6]}"
        ts = datetime.now().isoformat()
        result = self.execute_transaction(
            sql_ops=[
                (
                    "INSERT INTO readings (record_id, sensor_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
                    [record_id, 99999, ts, 20.0, 40.0]  # sensor_id 99999 does not exist
                )
            ],
            mongo_ops=[]
        )
        if result["status"] == "rolled_back":
            return {"test": "consistency", "passed": True, "reason": "FK constraint prevented invalid insert."}
        # Clean up if it somehow succeeded
        self._cleanup_test_data(record_id)
        return {"test": "consistency", "passed": False, "reason": "Invalid FK insert was allowed."}

    def test_isolation(self):
        """
        Isolation: two threads read and write concurrently.
        Verify final state is consistent (no lost updates).
        """
        record_id = f"iso-test-{uuid.uuid4().hex[:6]}"
        ts = datetime.now().isoformat()

        # Setup: insert a reading
        self.execute_transaction(
            sql_ops=[
                (
                    "INSERT INTO readings (record_id, sensor_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
                    [record_id, 1, ts, 20.0, 50.0]
                )
            ],
            mongo_ops=[
                (
                    "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
                    ["sensor_events", record_id, json.dumps({"event_type": "isolation_test"}), ts]
                )
            ]
        )

        errors = []

        def update_temp(val):
            try:
                with self._lock:
                    conn = self._sql_conn()
                    conn.execute("UPDATE readings SET temperature = ? WHERE record_id = ?", [val, record_id])
                    conn.commit()
                    conn.close()
            except Exception as e:
                errors.append(str(e))

        t1 = threading.Thread(target=update_temp, args=(30.0,))
        t2 = threading.Thread(target=update_temp, args=(35.0,))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        # Verify a single consistent value
        conn = self._sql_conn()
        row = conn.execute("SELECT temperature FROM readings WHERE record_id = ?", [record_id]).fetchone()
        conn.close()

        self._cleanup_test_data(record_id)

        if errors:
            return {"test": "isolation", "passed": False, "reason": f"Errors during concurrent updates: {errors}"}
        if row and row["temperature"] in (30.0, 35.0):
            return {"test": "isolation", "passed": True, "reason": f"Serialised updates produced consistent final value: {row['temperature']}"}
        return {"test": "isolation", "passed": False, "reason": f"Unexpected temperature: {row['temperature'] if row else 'None'}"}

    def test_durability(self):
        """
        Durability: insert data, close connections, reopen, verify data persists.
        """
        record_id = f"dur-test-{uuid.uuid4().hex[:6]}"
        ts = datetime.now().isoformat()

        # Insert
        self.execute_transaction(
            sql_ops=[
                (
                    "INSERT INTO readings (record_id, sensor_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
                    [record_id, 1, ts, 42.0, 75.0]
                )
            ],
            mongo_ops=[
                (
                    "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
                    ["sensor_events", record_id, json.dumps({"event_type": "durability_test"}), ts]
                )
            ]
        )

        # Re-open connections and check
        conn_sql = self._sql_conn()
        sql_row = conn_sql.execute("SELECT * FROM readings WHERE record_id = ?", [record_id]).fetchone()
        conn_sql.close()

        conn_mongo = self._mongo_conn()
        mongo_row = conn_mongo.execute(
            "SELECT * FROM documents WHERE collection = ? AND record_id = ?",
            ["sensor_events", record_id]
        ).fetchone()
        conn_mongo.close()

        self._cleanup_test_data(record_id)

        if sql_row and mongo_row:
            return {"test": "durability", "passed": True, "reason": "Data persisted after connection cycle in both backends."}
        return {"test": "durability", "passed": False,
                "reason": f"SQL found: {sql_row is not None}, Mongo found: {mongo_row is not None}"}

    def run_all_tests(self):
        """Run all ACID tests and return results."""
        return [
            self.test_atomicity(),
            self.test_consistency(),
            self.test_isolation(),
            self.test_durability()
        ]

    # ── cleanup ──────────────────────────────────────────────────

    def _cleanup_test_data(self, record_id):
        try:
            conn = self._sql_conn()
            conn.execute("DELETE FROM readings WHERE record_id = ?", [record_id])
            conn.commit()
            conn.close()
        except:
            pass
        try:
            conn = self._mongo_conn()
            conn.execute("DELETE FROM documents WHERE record_id = ?", [record_id])
            conn.commit()
            conn.close()
        except:
            pass


if __name__ == "__main__":
    tm = TransactionManager()
    results = tm.run_all_tests()
    for r in results:
        mark = "✅" if r["passed"] else "❌"
        print(f"{mark} {r['test'].upper()}: {r['reason']}")
