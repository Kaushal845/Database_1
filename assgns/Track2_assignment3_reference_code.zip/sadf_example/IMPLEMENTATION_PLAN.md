# SADF Example — Implementation Plan & User Guide

## Self-Adaptive Database Framework: IoT Smart Campus

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     LOGICAL DASHBOARD                       │
│         (HTML/CSS/JS · No physical storage exposed)         │
├─────────────────────────────────────────────────────────────┤
│                      Flask REST API                         │
│   /api/data/<entity>  ·  /api/query  ·  /api/acid-test     │
├──────────────────┬──────────────────────────────────────────┤
│   DB Engine      │   Transaction Manager                   │
│  (Unified CRUD)  │   (Cross-DB ACID coordination)          │
├──────────────────┴──────────────────────────────────────────┤
│                   Metadata Manager                          │
│         (JSON field→backend routing & schema map)           │
├────────────────────────┬────────────────────────────────────┤
│      sql.db            │         mongo.db                   │
│  (SQLite: Normalised   │  (SQLite simulating MongoDB:       │
│   relational tables)   │   JSON document store)             │
│                        │                                    │
│  ┌─────────┐           │  ┌──────────────────────────────┐  │
│  │ users   │           │  │ documents table              │  │
│  │ sensors │           │  │   collection | record_id     │  │
│  │ readings│           │  │   document (JSON) | ts       │  │
│  └─────────┘           │  └──────────────────────────────┘  │
│                        │  Collections: sensor_events,       │
│                        │    logs, alerts                    │
└────────────────────────┴────────────────────────────────────┘
```

**Key Design Principle:** The global field `record_id` links data across both databases. Users interact with logical entities — they never see SQL tables or MongoDB collections.

---

## 2. File Structure

| File | Purpose |
|------|---------|
| `metadata_manager.py` | Maintains `metadata.json` with field → backend routing. Each field knows if it lives in `sql`, `mongo`, or `both`. |
| `db_engine.py` | Unified CRUD engine. Routes reads/writes to the correct DB via metadata. Merges cross-DB results using `record_id`. |
| `transaction_manager.py` | Cross-database transaction coordination with rollback support. Contains ACID validation test methods. |
| `seed_data.py` | Creates tables in both DBs and populates sample IoT Smart Campus data. |
| `app.py` | Flask server with REST API endpoints and dashboard serving. |
| `templates/index.html` | Dashboard HTML — entity browser, CRUD modals, JSON query editor, ACID test panel. |
| `static/style.css` | Dark glassmorphism theme with responsive layout. |
| `static/app.js` | Frontend logic — API calls, dynamic table rendering, query examples. |
| `metadata.json` | Auto-generated on first run. Persists field routing decisions. |
| `sql.db` | SQLite file for structured relational data. |
| `mongo.db` | SQLite file simulating MongoDB document storage. |

---

## 3. How Metadata-Driven Routing Works

When a CRUD operation is requested:

1. **Lookup entity** in `metadata.json` → get field definitions
2. **Classify each field** → `sql`, `mongo`, or `both`
3. **Route data** → SQL fields go to `sql.db`, Mongo fields go to `mongo.db`
4. **On reads** → query both backends, merge results using `record_id`
5. **No re-classification** needed — metadata is pre-defined per session

Example metadata for the `readings` entity:
```json
{
  "temperature": {"backend": "sql",  "table": "readings"},
  "humidity":    {"backend": "sql",  "table": "readings"},
  "record_id":   {"backend": "both", "table": "readings", "collection": "sensor_events"}
}
```

---

## 4. Conditional Query System

The JSON query interface supports rich conditional filtering:

### Operators
| Operator | Meaning | Example |
|----------|---------|---------|
| `eq` | Equals (`=`) | `{"field": "role", "op": "eq", "value": "admin"}` |
| `ne` | Not equals (`!=`) | `{"field": "role", "op": "ne", "value": "student"}` |
| `gt` | Greater than (`>`) | `{"field": "temperature", "op": "gt", "value": 25}` |
| `gte` | Greater or equal (`>=`) | `{"field": "humidity", "op": "gte", "value": 60}` |
| `lt` | Less than (`<`) | `{"field": "temperature", "op": "lt", "value": 30}` |
| `lte` | Less or equal (`<=`) | `{"field": "humidity", "op": "lte", "value": 70}` |
| `like` | Pattern match | `{"field": "username", "op": "like", "value": "%ali%"}` |
| `in` | Set membership | `{"field": "role", "op": "in", "value": ["admin", "staff"]}` |

### Logical Groups
```json
// OR — match any condition
{"or": [
    {"field": "status", "op": "eq", "value": "active"},
    {"field": "status", "op": "eq", "value": "maintenance"}
]}

// AND — match all (default for top-level list)
{"and": [
    {"field": "temperature", "op": "gt", "value": 25},
    {"field": "humidity", "op": "lt", "value": 70}
]}
```

### Full Query Examples

**1. Simple read with field selection:**
```json
{
  "operation": "read",
  "entity": "users",
  "fields": ["username", "email", "role"]
}
```

**2. Conditional filter with sorting and limit:**
```json
{
  "operation": "read",
  "entity": "readings",
  "conditions": [
    {"field": "temperature", "op": "gt", "value": 25}
  ],
  "order_by": "temperature",
  "order": "desc",
  "limit": 5
}
```

**3. IN filter (set membership):**
```json
{
  "operation": "read",
  "entity": "users",
  "conditions": [
    {"field": "role", "op": "in", "value": ["admin", "staff"]}
  ]
}
```

**4. OR condition:**
```json
{
  "operation": "read",
  "entity": "sensors",
  "conditions": [
    {"or": [
      {"field": "sensor_type", "op": "eq", "value": "temperature"},
      {"field": "sensor_type", "op": "eq", "value": "humidity"}
    ]}
  ]
}
```

**5. Mongo-side filtering (severity):**
```json
{
  "operation": "read",
  "entity": "sensor_events",
  "conditions": [
    {"field": "severity", "op": "in", "value": ["high", "critical"]}
  ]
}
```

**6. Create a new record:**
```json
{
  "operation": "create",
  "entity": "logs",
  "data": {
    "log_level": "INFO",
    "source": "dashboard",
    "message": "Manual test entry",
    "context": {"user": "admin", "action": "test"}
  }
}
```

---

## 5. ACID Validation Tests

The `TransactionManager` provides 4 automated ACID tests:

| Test | What it validates | How |
|------|------------------|-----|
| **Atomicity** | All-or-nothing across both DBs | Inserts into sql+mongo, then attempts a duplicate insert that triggers UNIQUE constraint. Verifies both backends rolled back. |
| **Consistency** | FK constraints prevent invalid data | Attempts to insert a reading referencing non-existent `sensor_id=99999`. FK constraint blocks it. |
| **Isolation** | Concurrent writes → consistent state | Two threads update the same reading's temperature to different values. Lock serialization ensures no corruption. |
| **Durability** | Data persists after connection cycle | Inserts data, closes connections, reopens, and verifies data still exists. |

Run from CLI:
```bash
python3 transaction_manager.py
```

Run from dashboard: Open **ACID Tests** panel → **Run All Tests**

---

## 6. How to Run

### Prerequisites
- Python 3.8+  
- pip

### Setup & Launch
```bash
cd sadf_example

# Install dependencies
pip install -r requirements.txt

# Seed databases with sample data
python3 seed_data.py

# Run ACID tests (optional)
python3 transaction_manager.py

# Start the dashboard
python3 app.py
```

Open **http://localhost:5000** in your browser.

### Dashboard Features
- **Sidebar:** Click any entity (Users, Sensors, Readings, etc.) to view data
- **Search:** Filter displayed records by typing in the search box
- **CRUD:** Click `+ New Record` to create, `✎` to edit, `✕` to delete
- **JSON Query:** Click "JSON Query" tool → pick an example or write your own → Execute
- **ACID Tests:** Click "ACID Tests" → Run individual or all tests
- **Metadata:** Click ⚙ to view the field→backend routing map

---

## 7. Entities & Data Model

| Entity | Backend | Description |
|--------|---------|-------------|
| **users** | SQL only | Campus system users (username, email, role) |
| **sensors** | SQL only | IoT sensors (location, type, status, FK→users) |
| **readings** | SQL + Mongo | Structured readings (SQL: temp, humidity) merged with semi-structured events (Mongo: payload, severity, tags) |
| **sensor_events** | Mongo only | Variable-payload sensor events |
| **logs** | Mongo only | System/access logs with JSON context |
| **alerts** | Mongo only | Threshold-triggered alerts with details |

All cross-DB entities are linked by `record_id` (UUID).
