"""
Metadata Manager for the Self-Adaptive Database Framework (SADF).

Maintains a JSON metadata store that maps logical fields to physical backends.
This acts as the "brain" - no query touches a DB without consulting metadata first.
"""

import json
import os
import uuid
from datetime import datetime

METADATA_FILE = os.path.join(os.path.dirname(__file__), "metadata.json")

# Default metadata blueprint
DEFAULT_METADATA = {
    "session": {
        "session_id": None,
        "project_name": "IoT Smart Campus",
        "created_at": None,
        "description": "A hybrid database framework managing IoT sensor data across SQL and document stores."
    },
    "global_key": "record_id",
    "entities": {
        "users": {
            "description": "Campus system users (students, staff, admins)",
            "fields": {
                "user_id":    {"backend": "sql", "type": "INTEGER", "table": "users", "is_pk": True},
                "username":   {"backend": "sql", "type": "TEXT",    "table": "users", "is_unique": True},
                "email":      {"backend": "sql", "type": "TEXT",    "table": "users"},
                "role":       {"backend": "sql", "type": "TEXT",    "table": "users"}
            }
        },
        "sensors": {
            "description": "IoT sensors deployed across campus",
            "fields": {
                "sensor_id":  {"backend": "sql", "type": "INTEGER", "table": "sensors", "is_pk": True},
                "user_id":    {"backend": "sql", "type": "INTEGER", "table": "sensors", "is_fk": True, "references": "users(user_id)"},
                "location":   {"backend": "sql", "type": "TEXT",    "table": "sensors"},
                "sensor_type":{"backend": "sql", "type": "TEXT",    "table": "sensors"},
                "status":     {"backend": "sql", "type": "TEXT",    "table": "sensors"}
            }
        },
        "readings": {
            "description": "Structured sensor readings (temperature, humidity)",
            "fields": {
                "reading_id": {"backend": "sql", "type": "INTEGER", "table": "readings", "is_pk": True},
                "sensor_id":  {"backend": "sql", "type": "INTEGER", "table": "readings", "is_fk": True, "references": "sensors(sensor_id)"},
                "record_id":  {"backend": "both","type": "TEXT",    "table": "readings", "collection": "sensor_events", "is_global": True},
                "timestamp":  {"backend": "sql", "type": "TEXT",    "table": "readings"},
                "temperature":{"backend": "sql", "type": "REAL",    "table": "readings"},
                "humidity":   {"backend": "sql", "type": "REAL",    "table": "readings"}
            }
        },
        "sensor_events": {
            "description": "Semi-structured sensor event data (variable payloads)",
            "fields": {
                "record_id":  {"backend": "both","type": "TEXT",    "table": "readings", "collection": "sensor_events", "is_global": True},
                "event_type": {"backend": "mongo","type": "TEXT",   "collection": "sensor_events"},
                "payload":    {"backend": "mongo","type": "JSON",   "collection": "sensor_events"},
                "severity":   {"backend": "mongo","type": "TEXT",   "collection": "sensor_events"},
                "tags":       {"backend": "mongo","type": "JSON",   "collection": "sensor_events"}
            }
        },
        "logs": {
            "description": "System and access logs (unstructured)",
            "fields": {
                "record_id":  {"backend": "mongo","type": "TEXT",   "collection": "logs", "is_global": True},
                "log_level":  {"backend": "mongo","type": "TEXT",   "collection": "logs"},
                "source":     {"backend": "mongo","type": "TEXT",   "collection": "logs"},
                "message":    {"backend": "mongo","type": "TEXT",   "collection": "logs"},
                "context":    {"backend": "mongo","type": "JSON",   "collection": "logs"}
            }
        },
        "alerts": {
            "description": "Threshold-triggered alerts from sensors",
            "fields": {
                "record_id":  {"backend": "mongo","type": "TEXT",   "collection": "alerts", "is_global": True},
                "alert_type": {"backend": "mongo","type": "TEXT",   "collection": "alerts"},
                "triggered_by":{"backend": "mongo","type": "TEXT",  "collection": "alerts"},
                "details":    {"backend": "mongo","type": "JSON",   "collection": "alerts"},
                "resolved":   {"backend": "mongo","type": "INTEGER","collection": "alerts"}
            }
        }
    }
}


class MetadataManager:
    """Manages metadata for field-to-backend routing."""

    def __init__(self):
        self.metadata = self._load_or_init()

    # ── persistence ──────────────────────────────────────────────

    def _load_or_init(self):
        if os.path.exists(METADATA_FILE):
            with open(METADATA_FILE, "r") as f:
                return json.load(f)
        else:
            meta = DEFAULT_METADATA.copy()
            meta["session"]["session_id"] = str(uuid.uuid4())[:8]
            meta["session"]["created_at"] = datetime.now().isoformat()
            self._save(meta)
            return meta

    def _save(self, meta=None):
        if meta is None:
            meta = self.metadata
        with open(METADATA_FILE, "w") as f:
            json.dump(meta, f, indent=2)

    # ── public API ───────────────────────────────────────────────

    def get_session_info(self):
        return self.metadata["session"]

    def get_entities(self):
        """Return list of logical entity names with descriptions and field lists."""
        return {
            name: {
                "description": info["description"],
                "fields": list(info["fields"].keys())
            }
            for name, info in self.metadata["entities"].items()
        }

    def get_entity_fields(self, entity_name):
        """Return field definitions for a logical entity."""
        entity = self.metadata["entities"].get(entity_name)
        if not entity:
            raise ValueError(f"Unknown entity: {entity_name}")
        return entity["fields"]

    def get_routing(self, entity_name):
        """
        Return {"sql_fields": [...], "mongo_fields": [...], "table": ..., "collection": ...}
        telling the DB engine where each field lives.
        """
        fields = self.get_entity_fields(entity_name)
        sql_fields = []
        mongo_fields = []
        table = None
        collection = None
        for fname, fmeta in fields.items():
            backend = fmeta.get("backend", "mongo")
            if backend in ("sql", "both"):
                sql_fields.append(fname)
                if "table" in fmeta:
                    table = fmeta["table"]
            if backend in ("mongo", "both"):
                mongo_fields.append(fname)
                if "collection" in fmeta:
                    collection = fmeta["collection"]
        return {
            "sql_fields": sql_fields,
            "mongo_fields": mongo_fields,
            "table": table,
            "collection": collection
        }

    def get_global_key(self):
        return self.metadata["global_key"]

    def get_full_metadata(self):
        return self.metadata

    def reload(self):
        self.metadata = self._load_or_init()
