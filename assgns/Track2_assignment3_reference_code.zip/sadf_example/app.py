"""
Flask Application for the SADF Logical Dashboard.

Serves the web dashboard and exposes REST API endpoints
for CRUD operations, logical queries, metadata viewing, and ACID tests.
"""

from flask import Flask, jsonify, request, render_template
from db_engine import DBEngine
from metadata_manager import MetadataManager
from transaction_manager import TransactionManager

app = Flask(__name__)
engine = DBEngine()
meta   = MetadataManager()
txn    = TransactionManager()


# ── Pages ────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/docs")
def docs():
    return render_template("docs.html")


# ── Session & Metadata ──────────────────────────────────────

@app.route("/api/session")
def api_session():
    return jsonify(meta.get_session_info())


@app.route("/api/metadata")
def api_metadata():
    return jsonify(meta.get_full_metadata())


@app.route("/api/entities")
def api_entities():
    return jsonify(meta.get_entities())


# ── CRUD ─────────────────────────────────────────────────────

@app.route("/api/data/<entity>", methods=["GET"])
def api_read(entity):
    filters = {k: v for k, v in request.args.items()}
    try:
        data = engine.read(entity, filters if filters else None)
        return jsonify({"status": "ok", "entity": entity, "count": len(data), "data": data})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


@app.route("/api/data/<entity>", methods=["POST"])
def api_create(entity):
    body = request.get_json(force=True)
    try:
        record_id = engine.create(entity, body)
        return jsonify({"status": "ok", "record_id": record_id}), 201
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


@app.route("/api/data/<entity>/<record_id>", methods=["PUT"])
def api_update(entity, record_id):
    body = request.get_json(force=True)
    try:
        engine.update(entity, record_id, body)
        return jsonify({"status": "ok", "record_id": record_id})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


@app.route("/api/data/<entity>/<record_id>", methods=["DELETE"])
def api_delete(entity, record_id):
    try:
        engine.delete(entity, record_id)
        return jsonify({"status": "ok", "record_id": record_id})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


# ── Logical JSON Query ──────────────────────────────────────

@app.route("/api/query", methods=["POST"])
def api_query():
    body = request.get_json(force=True)
    try:
        result = engine.execute_query(body)
        return jsonify(result)
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


@app.route("/api/search", methods=["GET"])
def api_search():
    q = request.args.get("q", "")
    try:
        results = engine.search_all(q)
        return jsonify({"status": "ok", "count": len(results), "data": results})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 400


# ── ACID Tests ───────────────────────────────────────────────

@app.route("/api/acid-test/<test_name>", methods=["POST"])
def api_acid_test(test_name):
    test_map = {
        "atomicity":   txn.test_atomicity,
        "consistency": txn.test_consistency,
        "isolation":   txn.test_isolation,
        "durability":  txn.test_durability,
        "all":         txn.run_all_tests,
    }
    fn = test_map.get(test_name)
    if not fn:
        return jsonify({"error": f"Unknown test: {test_name}"}), 400
    result = fn()
    return jsonify(result if isinstance(result, list) else [result])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
