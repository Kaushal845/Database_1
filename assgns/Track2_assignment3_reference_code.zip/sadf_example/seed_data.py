"""
Seed Data Script for the Self-Adaptive Database Framework (SADF).

Creates tables in sql.db, initialises mongo.db, and populates both
with sample IoT Smart Campus data.
"""

import sqlite3
import json
import uuid
import os
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(__file__)
SQL_DB   = os.path.join(BASE_DIR, "sql.db")
MONGO_DB = os.path.join(BASE_DIR, "mongo.db")


def create_sql_tables():
    """Create normalised relational tables in sql.db."""
    conn = sqlite3.connect(SQL_DB)
    conn.execute("PRAGMA foreign_keys=ON")

    conn.executescript("""
        DROP TABLE IF EXISTS readings;
        DROP TABLE IF EXISTS sensors;
        DROP TABLE IF EXISTS users;

        CREATE TABLE users (
            user_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            username  TEXT    NOT NULL UNIQUE,
            email     TEXT    NOT NULL,
            role      TEXT    NOT NULL DEFAULT 'student'
        );

        CREATE TABLE sensors (
            sensor_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            location    TEXT    NOT NULL,
            sensor_type TEXT    NOT NULL,
            status      TEXT    NOT NULL DEFAULT 'active',
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );

        CREATE TABLE readings (
            reading_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            sensor_id   INTEGER NOT NULL,
            record_id   TEXT    NOT NULL UNIQUE,
            timestamp   TEXT    NOT NULL,
            temperature REAL,
            humidity    REAL,
            FOREIGN KEY (sensor_id) REFERENCES sensors(sensor_id)
        );
    """)
    conn.commit()
    conn.close()
    print("✅ sql.db tables created.")


def create_mongo_tables():
    """Create the document store table in mongo.db."""
    conn = sqlite3.connect(MONGO_DB)
    conn.executescript("""
        DROP TABLE IF EXISTS documents;

        CREATE TABLE documents (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            collection  TEXT    NOT NULL,
            record_id   TEXT    NOT NULL,
            document    TEXT    NOT NULL,
            created_at  TEXT    NOT NULL,
            UNIQUE(collection, record_id)
        );
    """)
    conn.commit()
    conn.close()
    print("✅ mongo.db documents table created.")


def rid():
    return str(uuid.uuid4())[:12]


def seed_data():
    now = datetime.now()

    # ── Users ────────────────────────────────────────────────
    users = [
        ("alice",   "alice@iitgn.ac.in",   "admin"),
        ("bob",     "bob@iitgn.ac.in",     "staff"),
        ("charlie", "charlie@iitgn.ac.in", "student"),
        ("diana",   "diana@iitgn.ac.in",   "student"),
        ("eve",     "eve@iitgn.ac.in",     "staff"),
    ]

    conn_sql = sqlite3.connect(SQL_DB)
    conn_sql.execute("PRAGMA foreign_keys=ON")
    for u in users:
        conn_sql.execute("INSERT INTO users (username, email, role) VALUES (?, ?, ?)", u)
    conn_sql.commit()
    print(f"✅ Inserted {len(users)} users.")

    # ── Sensors ──────────────────────────────────────────────
    sensors = [
        (1, "Library – Floor 1",    "temperature", "active"),
        (1, "Library – Floor 2",    "humidity",    "active"),
        (2, "Lab AB1-302",          "temperature", "active"),
        (2, "Lab AB1-302",          "motion",      "active"),
        (3, "Hostel H4 – Lobby",    "temperature", "active"),
        (4, "Cafeteria",            "humidity",     "maintenance"),
        (5, "Admin Block – Gate",   "access",      "active"),
    ]
    for s in sensors:
        conn_sql.execute(
            "INSERT INTO sensors (user_id, location, sensor_type, status) VALUES (?, ?, ?, ?)", s
        )
    conn_sql.commit()
    print(f"✅ Inserted {len(sensors)} sensors.")

    # ── Readings (SQL) + Sensor Events (Mongo) ──────────────
    conn_mongo = sqlite3.connect(MONGO_DB)
    reading_records = []
    for i in range(15):
        r_id = rid()
        ts = (now - timedelta(hours=15 - i)).isoformat()
        sensor_id = (i % len(sensors)) + 1
        temp = round(22.0 + (i * 0.7) + ((-1) ** i * 1.2), 2)
        hum  = round(55.0 + (i * 0.5), 2)

        # SQL side
        conn_sql.execute(
            "INSERT INTO readings (sensor_id, record_id, timestamp, temperature, humidity) VALUES (?, ?, ?, ?, ?)",
            [sensor_id, r_id, ts, temp, hum]
        )

        # Mongo side – sensor event doc
        event_doc = {
            "event_type": ["spike", "normal", "drop", "alert"][i % 4],
            "payload": {"raw_value": temp, "unit": "°C", "battery": round(95 - i * 0.3, 1)},
            "severity": ["low", "medium", "high", "critical"][i % 4],
            "tags": [["indoor", "library"], ["indoor", "lab"], ["outdoor"], ["indoor", "hostel"]][i % 4]
        }
        conn_mongo.execute(
            "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
            ["sensor_events", r_id, json.dumps(event_doc), ts]
        )
        reading_records.append(r_id)

    conn_sql.commit()
    conn_mongo.commit()
    print(f"✅ Inserted {len(reading_records)} readings + sensor events.")

    # ── Logs (Mongo only) ────────────────────────────────────
    log_entries = [
        {"log_level": "INFO",    "source": "auth-service",   "message": "User alice logged in",           "context": {"ip": "10.0.1.50",  "method": "SSO"}},
        {"log_level": "WARNING", "source": "sensor-gateway",  "message": "Sensor 6 heartbeat missed",     "context": {"sensor_id": 6, "last_seen": (now - timedelta(minutes=30)).isoformat()}},
        {"log_level": "ERROR",   "source": "db-engine",       "message": "Connection pool exhausted",      "context": {"pool_size": 10, "active": 10}},
        {"log_level": "INFO",    "source": "dashboard",       "message": "Report generated for March",     "context": {"report_type": "monthly", "pages": 12}},
        {"log_level": "DEBUG",   "source": "ingestion",       "message": "Batch 42 processed (200 docs)",  "context": {"batch_id": 42, "duration_ms": 340}},
    ]
    for log in log_entries:
        r_id = rid()
        conn_mongo.execute(
            "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
            ["logs", r_id, json.dumps(log), now.isoformat()]
        )
    conn_mongo.commit()
    print(f"✅ Inserted {len(log_entries)} log entries.")

    # ── Alerts (Mongo only) ──────────────────────────────────
    alert_entries = [
        {"alert_type": "threshold_exceeded", "triggered_by": "sensor_3", "details": {"metric": "temperature", "value": 38.5, "threshold": 35.0}, "resolved": 0},
        {"alert_type": "device_offline",     "triggered_by": "sensor_6", "details": {"downtime_min": 45}, "resolved": 0},
        {"alert_type": "threshold_exceeded", "triggered_by": "sensor_1", "details": {"metric": "humidity", "value": 90.2, "threshold": 85.0}, "resolved": 1},
    ]
    for alert in alert_entries:
        r_id = rid()
        conn_mongo.execute(
            "INSERT INTO documents (collection, record_id, document, created_at) VALUES (?, ?, ?, ?)",
            ["alerts", r_id, json.dumps(alert), now.isoformat()]
        )
    conn_mongo.commit()
    print(f"✅ Inserted {len(alert_entries)} alerts.")

    conn_sql.close()
    conn_mongo.close()
    print("\n🎉 Seed complete!  sql.db and mongo.db are ready.")


if __name__ == "__main__":
    create_sql_tables()
    create_mongo_tables()
    seed_data()
